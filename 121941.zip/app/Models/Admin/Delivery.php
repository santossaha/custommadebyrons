<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class Delivery extends Model
{
    protected $table = 'deliveries';
    public $timestamps = true;
}
