<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class OpeningTime extends Model
{
    protected $table = 'opening_times';
}
