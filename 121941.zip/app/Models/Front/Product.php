<?php

namespace App\Models\Front;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use DB;
class Product extends Model
{
	protected $table = 'products';
	public function product_image()
    {
        return $this->hasMany('App\Models\Front\ProductImage');
    }

    public function GetProductBySubcategory($sub_cat_id=''){
    	$sub_cat_id = (empty($sub_cat_id))?[]:explode(',',$sub_cat_id);
    	//echo "<pre>";print_r($sub_cat_id);die;
		$query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.sub_cat_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
              ->whereIn('products.sub_cat_id', $sub_cat_id)
               ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.id','DESC')->paginate(6);
        return $data;
	}
	public function GetAllProduct(){
		$query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.sub_cat_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
               ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.id','DESC')->paginate(6);
        return $data;
	}
	public function GetSubCategoryProduct($sub_cat_id=''){
		$query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.sub_cat_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
              ->where('products.sub_cat_id',$sub_cat_id)
              ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.id','DESC')->paginate(6);
        return $data;
	}
	public function GetProductByBrand($brand_id=''){
    	$brand_id = (empty($brand_id))?[]:explode(',',$brand_id);
    	//echo "<pre>";print_r($sub_cat_id);die;
		$query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.brand_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
              ->whereIn('products.brand_id', $brand_id)
               ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.id','DESC')->paginate(6);
        return $data;
	}
  public function GetCategoryProduct($category_id=''){
    $query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.category_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
              ->where('products.category_id',$category_id)
              ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.id','DESC')->paginate(6);
        return $data;
  }
  public function GetBrandProduct($brand_id=''){
    $query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.brand_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
              ->where('products.brand_id',$brand_id)
              ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.id','DESC')->paginate(6);
        return $data;
  }
  public function GetProductDetails($product_alias='',$product_code='')
  {
   // echo $product_alias.'<br>'.$product_code;die;
    $query = DB::table('products')->select('products.*')
              ->where('products.product_alias',$product_alias)
               ->where('products.product_code',$product_code)
              ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->first();
        return $data;
  }
  public function GetProductImageByID($product_id='')
  {
    $query = DB::table('product_images')->select('product_images.*')
              ->where('product_images.product_id',$product_id);
        $data = $query->orderBy('product_images.id','DESC')->get();
        return $data;
  }
  public function GetProductHighlightByID($product_id='')
  {
    $query = DB::table('product_highlights')->select('product_highlights.*')
              ->where('product_highlights.product_id',$product_id);
        $data = $query->orderBy('product_highlights.id','DESC')->get();
        return $data;
  }
  public function GetProductSizeByID($product_id=''){
    $query = DB::table('product_size')
              ->select('product_size.id','product_size.product_id','product_size.size_id','sizes.product_size')
              ->leftJoin('sizes', function ($join) {
                      $join->on('sizes.id','=','product_size.size_id')
                      ->where('sizes.status','=','Active');
                    })
              ->where('product_size.product_id',$product_id);
        $data = $query->orderBy('product_size.id','DESC')->get();
        return $data;
  }
  public function GetSimilarProduct($id='',$sub_cat_id=''){
    //echo $sub_cat_id;die;
    $query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.sub_cat_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
              ->where('products.id','!=',$id)
              ->where('products.sub_cat_id',$sub_cat_id)
              ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.id','DESC')->get();
        return $data;
  }
  public function getProductDetailsByID($product_id=''){
    $query = DB::table('products')
          ->select('products.*','product_images.product_image','product_images.product_id','product_images.default_image')
          ->leftJoin('product_images', 'product_images.product_id', '=', 'products.id')
          ->where('products.deleted_at',NULL)
          ->where('products.status','=','Active')
          ->where('products.id','=',$product_id)
          ->where('product_images.deleted_at',NULL)
          ->where('product_images.default_image','=',1);
    return $data = $query->first();
  }
  public function GetProductByDiscount($min_discount='',$max_discount=''){
      //echo $max_discount;die;
    $query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.brand_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
              ->whereBetween('products.discount', [$min_discount,$max_discount])
              ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.discount','ASC')->paginate(6);
        return $data;
  }
  public function GetProductByPrice($min_price='',$max_price=''){
      //echo $max_discount;die;
    $query = DB::table('products')
              ->select('products.id','products.product_code','products.product_name','products.product_alias','products.brand_id','products.discount','products.price','product_images.product_image')
              ->leftJoin('product_images', function ($join) {
                      $join->on('product_images.product_id','=','products.id')
                      ->where('product_images.default_image','=',1);
                    })
              ->whereBetween('products.price', [$min_price,$max_price])
              ->where('products.deleted_at',NULL)
              ->where('products.status','Active');
        $data = $query->orderBy('products.price','ASC')->paginate(6);
        return $data;
  }


}
