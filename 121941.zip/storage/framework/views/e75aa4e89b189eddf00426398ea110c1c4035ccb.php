<?php $__env->startSection('title'); ?>
Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="banner" class="inner-backg">
    <div class="inner-pg-banner">
       <img src="<?php echo e(url('/')); ?>/front/images/our_product_banner.jpeg" alt="">
        <div class="inner-ban-head">
            <h1>Our Product</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Our Product</li>
                </ol>
            </nav>
        </div>
    </div>

</section>


<!--Our Product-->
<section id="search-results" class="one-way-flight congain">
    <div class="container">
        <div class="row">
           <?php echo $__env->make('front.common.productSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-9">
                <div class="my-product">
                     <div class="loader" style="display: none;"></div>
                    <div class="row" id="search_result">
                    <?php echo $__env->make('front.ajax.pagination-search-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>

                </div>
                <div class="mobile-filter hidden-desktop visible-mobile"
                     style="position: fixed; right: 16px; bottom: 16px;">
                    <a href="javascript:void(0)" class="open-filter"> <i class="fas fa-sort-up"></i> Filter</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Our Product end-->


<!--Brands section-->

<script>
$(document).ready(function(){
    $(document).on('click', '#search_result .pagination a',function(event){
        //alert('test');
        event.preventDefault();
        $('li').removeClass('active');
        $(this).parent('li').addClass('active');
        var myurl = $(this).attr('href');
      // console.log($(this).attr('href').split('page='));
        var page=$(this).attr('href').split('page=')[1];
        ProductBandSearch(page);
        ProductSubcategorySearch(page);
        ProductDiscountSearch(page)

      });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\121941\resources\views/front/product/product.blade.php ENDPATH**/ ?>