<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section id="banner">
    <div class="owl-carousel owl-theme slide-ban">
      <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
          <?php if($banner['image']!=''): ?>
            <img src="<?php echo e(url($banner['image'])); ?>" alt="Slider<?php echo e($key); ?>">
          <?php else: ?>
            <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt="Slider<?php echo e($key); ?>">
          <?php endif; ?>
            <div class="cover">
                <div class="container">
                    <div class="header-content">
                        <div class="line"></div>
                        <h2>New Arrivals</h2>
                        <h1><?php echo e($banner['title']); ?></h1>
                        <a href="<?php echo e(url('products')); ?>" class="btn btn-outline-secondary">Shop Now</a>
                    </div>
                </div>
             </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </section>

<!-- sec1 -->
<div class="sec1">
    <div class="container-fluid">
        <div class="sec1-inner">
        <?php if($discount_data): ?>

        <?php $__currentLoopData = $discount_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php

            $new_arrival = isset($data->new_arrival)?$data->new_arrival:'';
            $latest_collection = isset($data->latest_collection)?$data->latest_collection:'';
            $best_selling = isset($data->best_selling)?$data->best_selling:'';
            if($new_arrival=='1'){
                $title = 'New Arrivals';
                $heading = 'Save';
                $discount = isset($data->discount)?$data->discount:'';
                $image = isset($data->product_image)?$data->product_image:'';
            }else if($latest_collection=='1'){
                $title = 'Best Selling';
                $heading = isset($data->sub_category_name)?$data->sub_category_name:'';
                $discount = isset($data->discount)?$data->discount:'';
                $image = isset($data->product_image)?$data->product_image:'';
            }else if($best_selling=='1'){
                 $title = 'Latest Collection';
                 $heading = 'Save';
                 $discount = isset($data->discount)?$data->discount:'';
                 $image = isset($data->product_image)?$data->product_image:'';
            }
        ?>
        <div class="sec1-l">
            <?php if($image!=''): ?>
                <img src="<?php echo e(url($image)); ?>" alt="">
            <?php else: ?>
                <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt="">
            <?php endif; ?>

            <div class="sec1-content">
                <h2><?php echo e($title); ?></h2>
                <h3><?php echo e($heading); ?> Up To <span><?php echo e($discount); ?>% Off</span></h3>
                <a href="<?php echo e(url('products')); ?>" class="btn btn-outline-secondary">Shop Now</a>
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    </div>

</div>

   <!--Shipping area start-->
  
<!--Shipping area end-->

<!-- Featured products -->
<div class="gallery">

    <div class="container-fluid">


        <div class="section-heading mb-2">
            <h2>New arrivals</h2>
        </div>

        <div class="gallery-wrap">
            <div class="gallery-menu">
                <ul>

                    <?php if($subcategories): ?>
                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="javascript:void(0)" onclick="SearchProduct('<?php echo $val->sub_cat_id?>')"><?php echo e(isset($val->sub_category_name)?$val->sub_category_name:''); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
          <div class="loader" style="display: none;"></div>
            <div class="grid" id="new_arrival_search_product">
            <?php if($new_arrival_products): ?>
              <?php $__currentLoopData = $new_arrival_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="grid-item">
                      <div class="gallery-item">
                          <figure class="ngo-gal">
                              <div class="image">
                                <?php if($pro['product_image'][0]->product_image!=''): ?>
                                  <img src="<?php echo e(url($pro['product_image'][0]->product_image)); ?>" alt=""/>
                                <?php else: ?>
                                  <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt=""/>
                                <?php endif; ?>
                                <div class="icons">
                                  <a href="javascript:void(0);"><i class="fas fa-shopping-cart add-cart" data-product-id="<?php echo e($pro->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1" ></i></a>
                                  <a href="javascript:void(0);"> <i class="far fa-heart whish-list" data-product-id="<?php echo e($pro->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1" ></i></a>
                                  <a href="<?php echo e(url('product/'.$pro->product_alias.'/'.$pro->product_code)); ?>"> <i class="far fa-eye"></i></a>
                                </div>
                                <a href="javascript:void(0);" class="add-to-cart add-cart" data-product-id="<?php echo e($pro->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1">Add to Cart</a>
                              </div>
                              <figcaption>
                                  <a href="<?php echo e(url('product/'.$pro->product_alias.'/'.$pro->product_code)); ?>"> <h2><?php echo e(isset($pro->product_name)?$pro->product_name:''); ?></h2></a>

                                  <div class="price">
                                       

                                        <p>
                                            <?php
                                                $discount = isset($pro->discount)?$pro->discount:'';
                                                $org_price = isset($pro->price)?$pro->price:'';
                                                $dis_amt = ($org_price*$discount)/100;
                                                $dis_price = ($org_price-$dis_amt);
                                            ?>
                                            $<?php echo e($dis_price); ?> <span class="line-through">$<?php echo e($org_price); ?></span>
                                        </p>
                                    </div>
                                </figcaption>
                            </figure>
                      </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>



            </div>
        </div>


<div class="prod-btn mx-auto  text-center justify-content-center align-self-center"><a href="<?php echo e(url('products')); ?>" class="btn btn-outline-secondary">View All</a></div>

    </div>
</div>


<!-- Latest Collections -->
<div class="sec1 latest-collection">
    <div class="container-fluid">
        <div class="section-heading mb-2">
            <h2>Our Latest Collections</h2>
        </div>

        <div class="sec1-inner">
        <?php if($latests): ?>
            <?php $__currentLoopData = $latests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sec1-l">
                    <?php if($value['product_image'][0]->product_image!=''): ?>
                        <img src="<?php echo e(url($value['product_image'][0]->product_image)); ?>" alt="">
                    <?php else: ?>
                        <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt="">
                    <?php endif; ?>
                    <div class="sec1-content">
                        <h2>Latest Collection</h2>
                        <h3><?php echo e(isset($value->product_name)?$value->product_name:''); ?></span></h3>
                        <p>

                            Lorem ipsum dolor sit amet, consectetur adipiscing magna. Mauris sed coqut odio.
                        </p>
                        <a href="<?php echo e(url('product/'.$value->product_alias.'/'.$value->product_code)); ?>" class="btn btn-outline-secondary">Shop Now</a>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>


<div class="product-collection gallery">
    <div class="owl-carousel owl-theme collect">
      <?php if($products): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item">
              <figure class="ngo-gal">
                  <div class="image">
                  <?php $image = isset($val['product_image'][0]->product_image)?$val['product_image'][0]->product_image:'';?>
                     <?php if($image!=''): ?>
                        <img src="<?php echo e(url($image)); ?>" alt=""/>
                      <?php else: ?>
                        <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt=""/>
                      <?php endif; ?>
                    <div class="icons">
                      <a href="javascript:void(0);"><i class="fas fa-shopping-cart add-cart" data-product-id="<?php echo e($val->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1"></i></a>
                      <a href="javascript:void(0);"> <i class="far fa-heart whish-list" data-product-id="<?php echo e($val->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1" ></i></a>
                      <a href="<?php echo e(url('product/'.$val->product_alias.'/'.$val->product_code)); ?>"> <i class="far fa-eye"></i></a>
                    </div>
                    <a href="<?php echo e(url('product/'.$val->product_alias.'/'.$val->product_code)); ?>" class="add-to-cart">Shop Now</a>
                  </div>
                  <figcaption>
                      <h2><?php echo e(isset($val->product_name)?$val->product_name:''); ?></h2>

                      <div class="price">
                       
                        <p>
                            <?php
                                $discount = isset($val->discount)?$val->discount:'0';
                               //s echo $discount;
                                $org_price = isset($val->price)?$val->price:'0';
                                $dis_amt = (($org_price*$discount)/100);
                                $dis_price = ($org_price-$dis_amt);
                            ?>
                            $<?php echo e(isset($dis_price)?$dis_price:''); ?> <span class="line-through">$<?php echo e(isset($org_price)?$org_price:''); ?></span>
                        </p>
                    </div>
                    </figcaption>
                </figure>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
</div>

    </div>

</div>



<!-- contact area -->
<div id="contact-area">
    <div class="container-fluid">
        <div class="section-heading mb-2">
            <h2>Contact Us Via Form</h2>
        </div>
        <div class="contact-page">
            <div class="row">
                <div class="col-md-12 contact-form">
                   <span id="msg"></span>
                   <span id="error_msg"></span>
                    <form id="contact_form" action="javascript:void(0);">
                        <div class="row">
                    <div class="col-md-4 ">
                        <div class="register-form" role="form">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputName">Your Name <span>*</span></label>
                                <input type="text" class="form-control unicase-form-control text-input" id="con_name" placeholder="Your Name" name="con_name">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="register-form" role="form">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputEmail1">Email Address <span>*</span></label>
                                <input type="email" class="form-control unicase-form-control text-input" id="con_email" name="con_email" placeholder="Email Address">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="register-form" role="form">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputTitle">Phone No <span>*</span></label>
                                <input type="tel" class="form-control unicase-form-control text-input" id="con_phone" name="con_phone" placeholder="Phone Number">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="register-form" role="form">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputComments">Subject <span>*</span></label>
                                <input type="text" class="form-control unicase-form-control text-input" id="con_sub" name="con_sub" placeholder="Subject">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="register-form" role="form">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputComments">Your Message <span>*</span></label>
                                <textarea class="form-control unicase-form-control" id="con_msg" name="con_msg"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 outer-bottom-small">
                        <button type="submit" class="btn btn-transparent btn-rounded btn-large" id="send_message">Send Message</button>
                    </div>
                </div>
                    </form>
                </div>


            </div><!-- /.contact-page -->
        </div>
    </div>
</div>

<!-- Brands section -->

<script>
    function SearchProduct(sub_cat_id){
       var _token = '<?php echo csrf_token() ?>';
            $.ajax({
                type: "post",
                url: "<?php echo e(route('new_arrival_product_search')); ?>",
                data: {
                    _token: _token,
                    sub_cat_id: sub_cat_id
                },
                beforeSend: function() {
                    $('.loader').show();
                },
                success: function(result) {
                    $('.loader').hide();
                    $("#new_arrival_search_product").html(result);
                    // }, 1000);
                }
            });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/121941/resources/views/front/home/index.blade.php ENDPATH**/ ?>