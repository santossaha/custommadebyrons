<?php $__env->startSection('title'); ?>
Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="banner" class="inner-backg">
    <div class="inner-pg-banner">
        <img src="<?php echo e(url('/')); ?>/front/images/our_product_banner.jpeg" alt="">
        <div class="inner-ban-head">
            <h1>Product Details</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Product Details</li>
                </ol>
            </nav>
        </div>
    </div>

</section>


<!--product details-->
<section id="product-details">
    <div class="container">
        <div class="row">
            <div class="col-md-6">

                <div id="product-image">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators custom-img-height">
                        <?php
                            $i=1;
                            foreach($product_images as $key => $image){ ?>
                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($key); ?>" class="<?php if($i==1){ echo 'active';}?>">
                           <?php if($image->product_image!=''): ?>
                                <img src="<?php echo e(url($image->product_image)); ?>" alt="0<?php echo e($key); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt="0<?php echo e($key); ?>">
                            <?php endif; ?>
                        </li>
                        <?php $i++; } ?>
                    </ol>
                    <div class="carousel-inner">

                        <?php
                            foreach($product_images as $ikey => $inner_image){
                                $item_class = ($inner_image->default_image == 1) ? 'carousel-item active' : 'carousel-item';
                            ?>
                        <div class="carousel-item <?php echo e($item_class); ?>">

                            <?php if($inner_image->product_image!=''): ?>
                                <img src="<?php echo e(url($inner_image->product_image)); ?>" class="d-block w-100" alt="0<?php echo e($ikey); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(url('/')); ?>/front/img/No-Image.png" class="d-block w-100" alt="0<?php echo e($ikey); ?>">
                            <?php endif; ?>

                        </div>
                        <?php } ?>


                                        </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
                </div>

                <div class="product-add-to-cart">
                    <ul>

                        <li><a href="javascript:void(0);" class="btn btn-outline-secondary"><i class="fa fa-shopping-cart add-cart " data-product-id="<?php echo e($product_id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1"> ADD TO CART </i> </a></li>
                       
                    </ul>
                </div>
            </div>
            <div class="col-md-6">
                <div class="product-details-text">
                    <h1><?php echo e(isset($data->product_name)?$data->product_name:''); ?></h1>
                    <ul class="ul-ratings">
                        
                        
                    </ul>
                    <div class="price">
                        
                    </div>
                    <div class="price-rs">
                        <ul>
                            <?php
                                $org_price = isset($data->price)?$data->price:'0';
                                $discount = isset($data->discount)?$data->discount:'';
                                $discount_amt = (($org_price*$discount)/100);
                                $price = ($org_price-$discount_amt);

                            ?>
                            <li><h2>$<?php echo e($price); ?></h2></li>
                             <?php if($data->discount): ?>
                                <li>
                                    <del>$<?php echo e($org_price); ?></del>
                                </li>
                                <li><h4><?php echo e($data->discount); ?>% off</h4></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <div class="delivery">
                        <h3>Delivery</h3>
                        <!-- Load icon library -->
                        <link rel="stylesheet"
                              href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

                        <!-- The form -->
                        <form class="example" id="delivery_check_form">
                            <input type="text" placeholder="Enter pincode" name="pincode" id="pincode">
                            <button type="submit" id="chk_btn">Check</button>
                            <span id="error_pincode"></span>
                        </form>

                    </div>


                    <div class="highlights-warranty">
                        <?php if($product_highlights): ?>
                            <h3>Highlights</h3>
                            <ul>
                                <?php $__currentLoopData = $product_highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><p><i class="fa fa-circle"></i><?php echo e(isset($highlight->highlights)?$highlight->highlights:''); ?></p></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        <?php endif; ?>
                        <?php if($data->warranty): ?>
                            <h3>Warranty</h3>
                            <p><?php echo e(isset($data->warranty)?$data->warranty:''); ?></p>
                        <?php endif; ?>
                        <?php if($data->description): ?>
                            <h3>Description</h3>
                            <p><?php echo $data->description; ?></p>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php if(count($similar_products)>0): ?>
    <section id="similar-products">
        <div class="container">
            <div class="section-heading mb-2">
                <h2>Similar Products</h2>
            </div>

            <div class="my-product">
                <div class="owl-carousel owl-theme" id="product_slider">
                    <?php $__currentLoopData = $similar_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="gallery-item">
                                <figure class="ngo-gal">
                                    <div class="image">
                                        <?php if($product->product_image!=''): ?>
                                            <img src="<?php echo e(url($product->product_image)); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt="">
                                        <?php endif; ?>
                                        <div class="icons">
                                           <a href="javascript:void(0);"><i class="fas fa-shopping-cart add-cart" data-product-id="<?php echo e($data->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1" ></i></a>
                                            <a href="javascript:void(0);"> <i class="far fa-heart whish-list" data-product-id="<?php echo e($data->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1" ></i></a>
                                            <a href="<?php echo e(url('product/'.$product->product_alias.'/'.$product->product_code)); ?>"> <i class="far fa-eye"></i></a>
                                        </div>
                                        <a href="javascript:void(0);" class="add-to-cart add-cart" data-product-id="<?php echo e($product->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1">Add to Cart</a>
                                    </div>
                                    <figcaption>
                                        <h2><?php echo e(isset($product->product_name)?$product->product_name:''); ?></h2>

                                        <div class="price">

                                          

                                            <p>
                                                <?php
                                                    $org_price = isset($product->price)?$product->price:'';
                                                    $discount = isset($product->discount)?$product->discount:'';
                                                    $discount_amt = (($org_price*$discount)/100);
                                                    $price = ($org_price-$discount_amt);
                                                ?>
                                                $<?php echo e($price); ?><br>

                                                <?php if($product->discount): ?><span class="line-through">$<?php echo e($org_price); ?></span><?php endif; ?>
                                            </p>
                                        </div>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
<?php endif; ?>


<!--Brands section-->

<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $("#delivery_check_form").validate({
            rules: {
                pincode: {
                    required: true,
                }
            },
            messages: {
                pincode: {
                    required: "Enter postal code.",
                }
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "pincode") {
                    error.insertAfter("#error_pincode");
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                var pincode = $('#pincode').val();
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('product_delivered_checked')); ?>",
                    data: {pincode: pincode},
                    beforeSend: function() {
                        $('#chk_btn').html('Checking.....');
                        $('#chk_btn').prop('disable', true);
                         //$('.loader').show();
                    },
                    success: function(result) {
                        console.log(result);
                        $('#chk_btn').html('<button type="submit" id="chk_btn">Check</button>');
                        alert('succ');
                        $('.loader').hide();
                        setTimeout(function() {
                        $("#success_msg").html(result);
                        }, 2000);
                    }
                });
                return false
            }
        })

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custommadebyrons/public_html/resources/views/front/product/product-details.blade.php ENDPATH**/ ?>