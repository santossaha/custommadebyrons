<?php $__env->startSection('title'); ?>
Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<!--Our Product-->
<section id="search-results" class="one-way-flight congain">
    <div class="container">
        <div class="row">
           <div class="col-md-3"></div>
          
            <div class="col-md-12">
                <div class="my-product">
                    <div class="jumbotron text-center">
                        <h1 class="display-3">Thank You!</h1>
                        <p class="lead"><strong>Order has been Successfully</p>
                        <hr>

                        <p class="lead">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('home')); ?>" role="button">Continue to homepage</a>
                        </p>
                    </div>
                 <div class="row">
                    

                   
                 
               
                 </div>
                <div class="mobile-filter hidden-desktop visible-mobile"
                     style="position: fixed; right: 16px; bottom: 16px;">
                    <a href="javascript:void(0)" class="open-filter"> <i class="fas fa-sort-up"></i> Filter</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Our Product end-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/121941/resources/views/front/order/order-success.blade.php ENDPATH**/ ?>