<?php $__env->startSection('content'); ?>
    <style>
        .profile{
            text-align: center;
        }
    </style>
    <h4 class="mb"><b>Edit Delivery Charge</b></h4>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success profile">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <strong><?php echo e(Session::get('success')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="row mt">
        <div class="col-lg-12">
            <div class="form-panel">
                <form class="form-horizontal" action="<?php echo e(route('admin::updateDeliveryCharge',$info['id'])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Min Amount</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e($info['min_delivery_charge']); ?>" id="min_delivery_charge" name="min_delivery_charge" readonly placeholder="Enter Min Amount" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Max Amount</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e($info['max_delivery_charge']); ?>" id="max_delivery_charge" name="max_delivery_charge" placeholder="Enter Max Amount" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Delivery Charge <small>(Delivery charge will be applicable. if the less than max amount is exceeded)</small></label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e($info['delivery_amount']); ?>" id="delivery_amount" name="delivery_amount" placeholder="Enter Delivery Amount" />
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-12" style="text-align: center">
                            <button type="submit" class="btn btn-sm btn-success">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- col-lg-12-->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.fancybox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/121941/resources/views/admin/delivery_charge/edit.blade.php ENDPATH**/ ?>