 <?php if(count($datums)>0): ?>
                        <?php $__currentLoopData = $datums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="gallery-item">
                                    <figure class="ngo-gal">
                                        <div class="image">
                                            <?php if($data->product_image!=''): ?>
                                                <img src="<?php echo e(url($data->product_image)); ?>" alt="">
                                            <?php else: ?>
                                                <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt="">
                                            <?php endif; ?>
                                            <div class="icons">
                                                 <a href="javascript:void(0);"><i class="fas fa-shopping-cart add-cart" data-product-id="<?php echo e($data->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1" ></i></a>
                                                <a href="javascript:void(0);"> <i class="far fa-heart whish-list" data-product-id="<?php echo e($data->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1" ></i></a>
                                                <a href="<?php echo e(url('product/'.$data->product_alias.'/'.$data->product_code)); ?>"> <i class="far fa-eye"></i></a>
                                            </div>
                                            <a href="javascript:void(0);" class="add-to-cart add-cart" data-product-id="<?php echo e($data->id); ?>" data-uid="<?php echo e($user_id); ?>" data-product-quantity="1">Add to Cart</a>
                                        </div>
                                        <figcaption>
                                            <a href="<?php echo e(url('product/'.$data->product_alias.'/'.$data->product_code)); ?>">  <h2><?php echo e($data->product_name); ?></h2></a>

                                            <div class="price" >

                                               

                                                <p>
                                                <?php
                                                    $discount = isset($data->discount)?$data->discount:'0';
                                                    $org_price = isset($data->price)?$data->price:'0';
                                                    $dis_amt = ($org_price*$discount)/100;
                                                    $dis_price = ($org_price-$dis_amt);
                                                ?>
                                                $<?php echo e(isset($dis_price)?$dis_price:''); ?> <span class="line-through">$<?php echo e(isset($org_price)?$org_price:''); ?></span>
                                                </p>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="col-md-4">
                                <div class="gallery-item">
                                        <span>No Product here!</span>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="my-pagination">
                        <ul class="pagination">
                            <li class="page-item">
                               <?php echo e($datums->links()); ?>

                            </li>
                            <!-- <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">Next</a></li> -->
                        </ul>
                    </div>
<?php /**PATH /home/custommadebyrons/public_html/resources/views/front/ajax/pagination-search-product.blade.php ENDPATH**/ ?>