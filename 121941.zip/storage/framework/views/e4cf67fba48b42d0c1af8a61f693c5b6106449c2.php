<?php $__env->startSection('content'); ?>
    <section id="main-content">
        <section class="wrapper">
            <h3><i class="fa fa-angle-right"></i> Opening Time</h3>

            <div class="row mt">
                <!--  DATE PICKERS -->
                <div class="col-lg-12">
                    <div class="form-panel">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div><br />
                        <?php endif; ?>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success profile">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <strong><?php echo e(Session::get('success')); ?></strong>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger profile">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <strong><?php echo e(Session::get('error')); ?></strong>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('admin::openingTimeSave')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal style-form">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label class="control-label col-md-3">Mon – Fri</label>
                                <div class="col-md-4">
                                    <div class="input-group input-large" >
                                        <input type="time" class="form-control" name="mon_to_fri_opening" value="<?php echo e(isset($view->mon_to_fri_opening)? $view->mon_to_fri_opening : ''); ?>">
                                        <span class="input-group-addon">To</span>
                                        <input type="time" class="form-control" name="mon_to_fri_closing" value="<?php echo e(isset($view->mon_to_fri_closing)? $view->mon_to_fri_closing : ''); ?>">

                                    </div>
                                    <span class="help-block">Select time range</span>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-md-3">Sat</label>
                                <div class="col-md-4">
                                    <div class="input-group input-large" >
                                        <input type="time" class="form-control" name="opening_sat" value="<?php echo e(isset($view->opening_sat)? $view->opening_sat : ''); ?>">
                                        <span class="input-group-addon">To</span>
                                        <input type="time" class="form-control" name="closing_sat" value="<?php echo e(isset($view->closing_sat)? $view->closing_sat : ''); ?>">

                                    </div>
                                    <span class="help-block">Select time range</span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-md-3">Sun</label>
                                <div class="col-md-4">
                                    <div class="input-group input-large" >
                                        <input type="time" class="form-control" name="opening_sun" value="<?php echo e(isset($view->opening_sun)? $view->opening_sun : ''); ?>">
                                        <span class="input-group-addon">To</span>
                                        <input type="time" class="form-control" name="closing_sun" value="<?php echo e(isset($view->closing_sun)? $view->closing_sun : ''); ?>">

                                    </div>
                                    <span class="help-block">Select time range</span>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-sm btn-success">Submit</button>

                        </form>
                    </div>
                    <!-- /form-panel -->
                </div>
                <!-- /col-lg-12 -->
            </div>
            <!-- /row -->
        </section>
        <!-- /wrapper -->
    </section>
    <?php $__env->startPush('scripts'); ?>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custommadebyrons/public_html/resources/views/admin/opening_time/index.blade.php ENDPATH**/ ?>