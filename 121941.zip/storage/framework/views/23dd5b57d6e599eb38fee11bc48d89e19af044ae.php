<?php $__env->startSection('title'); ?>
Our Store
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="banner" class="inner-backg">
    <div class="inner-pg-banner">
        <img src="<?php echo e(url('/')); ?>/front/images/our_product_banner.jpeg" alt="">
        <div class="inner-ban-head">
            <h1><?php echo e($pages['page_name']); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($pages['page_name']); ?></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<section id="our-store">
    <div class="container">
        <div class="row">
            <?php echo $pages['description']; ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\121941\resources\views/front/pages/our-store.blade.php ENDPATH**/ ?>