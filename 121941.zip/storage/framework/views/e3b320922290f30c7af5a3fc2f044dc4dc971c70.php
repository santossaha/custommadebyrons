<div class="col-md-4 side-nav">
    <div class="heading">
        <?php $users = Auth::guard('web')->user();?>
        <?php if($users->image!=''): ?>
            <img src="<?php echo e(url($users->image)); ?>" alt="">
        <?php else: ?>
            <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt="">
        <?php endif; ?>

        <div class="info">
            <h3><a href="<?php echo e(route('my_profile')); ?>"><?php echo e(isset($users->name)?$users->name:''); ?></a></h3>
            <p><a href="mailto:<?php echo e(isset($users->email)?$users->email:''); ?>"><?php echo e(isset($users->email)?$users->email:''); ?></a></p>
            <p><?php echo e(isset($users->phone)?$users->phone:''); ?></p>
        </div>
    </div>
    <ul class="categories">
        <li class="<?php if(Request::segment(1)=='my-order'){ echo 'active';}?>"><i class="fab fa-first-order"></i><a href="<?php echo e(route('myOrder')); ?>"> My Order</a></li>
        <li class="<?php if(Request::segment(1)=='my-profile'){ echo 'active';}?>"><i class="fa fa-user" aria-hidden="true"></i><a href="<?php echo e(route('my_profile')); ?>">Profile Information</a></li>
        <li class="<?php if(Request::segment(1)=='user-address'){ echo 'active';}?>"><i class="far fa-address-card"></i><a href="<?php echo e(route('user_address')); ?>">Manage Addresses</a></li>
        <li class="<?php if(Request::segment(1)=='wishlist'){ echo 'active';}?>"><i class="fas fa-heart"></i><a href="<?php echo e(route('wishlist')); ?>"> My Wishlist</a></li>
        <li class="<?php if(Request::segment(1)=='user-change-password'){ echo 'active';}?>"><i class="fa fa-unlock"></i><a href="<?php echo e(route('user_change_password')); ?>"> Change Password</a></li>
        <li><i class="fas fa-sign-out-alt"></i><a href="<?php echo e(route('user_logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form2').submit();"> Log Out</a></li>
        <form id="logout-form2" action="<?php echo e(route('user_logout')); ?>" method="POST" style="display: inline;">
            <?php echo e(csrf_field()); ?>

        </form>
    </ul>
</div>
<?php /**PATH /var/www/html/121941/resources/views/front/common/leftsidebar.blade.php ENDPATH**/ ?>