<?php $__env->startSection('title'); ?>
User Address
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section id="banner" class="inner-backg">
        <div class="inner-pg-banner">
            <img src="<?php echo e(url('/')); ?>/front/images/blog-bg.jpg" alt="">
            <div class="inner-ban-head">
                <h1>My Address</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">My Address</li>
                    </ol>
                </nav>
            </div>
        </div>

    </section>

    <!--=====privacy & Policy page -content======-->

    <section class="user-dashboard">
        <div class="container-fluid">
            <div class="row">
                <?php echo $__env->make('front.common.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-md-8">
                    <div class="row order-list custom-address-height" id="defult_address">
                       <div class="col-md-12">
                       <?php echo $__env->make('front.common.Messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <div class="user-manage-address">
                           <?php if(count($user_address)>0): ?>
                               <div class="">
                                   <span class="save-add">Saved Addresses</span>
                                   <span class="new-add"><i class="fas fa-long-arrow-alt-right"></i> <a href="<?php echo e(route('add_user_address')); ?>">Add New Address</a></span>
                               </div>
                               <?php $__currentLoopData = $user_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <div class="defult-address">
                                   <div class="dflt-ad">
                                    <?php
                                      $name = $data->first_name.' '.$data->last_name;
                                    ?>
                                       <p><?php echo e($name); ?></p>
                                       <span><?php echo e(isset($data->address_one)?$data->address_one:''); ?></span>
                                       <?php if($data->address_two!=''): ?>
                                       <span><?php echo e(isset($data->address_two)?$data->address_two:''); ?></span>
                                       <?php endif; ?>
                                       <span><?php echo e(isset($data->city)?$data->city:''); ?> - <?php echo e(isset($data->pincode)?$data->pincode:''); ?></span>
                                       <span><?php echo e(isset($data->state_name)?$data->state_name:''); ?>, <?php echo e(isset($data->country_name)?$data->country_name:''); ?></span>
                                       <span>Mobile: <?php echo e(isset($data->phone)?$data->phone:''); ?></span>
                                       <div>
                                           <?php if($data->default_address=='1'): ?>
                                            <a href="javascript:;">Make This Default</a>
                                           <?php else: ?>
                                            <a href="javascript:;">Other Address</a>
                                           <?php endif; ?>
                                       </div>
                                   </div>
                                   <?php if($data->default_address=='1'): ?>
                                   <div class="address-edit-remove" >
                                       <span class="address-edit"><a href="<?php echo e(route('edit_user_address')); ?>">Edit</a></span>
                                       <span class="edit-line"></span>
                                       <span class="address-remove"><a href="javascript:;" onclick="UserAddressDelete(<?php echo $data->id;?>)">Remove</a></span>
                                   </div>
                                   <?php endif; ?>
                               </div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php else: ?>
                               <div class="emty-address">
                                    <span><i class="fas fa-map-marker-alt"></i></span>
                                    <span>Save Your Address Now</span>
                                   <span class="new-add"><i class="fas fa-long-arrow-alt-right"></i> <a href="<?php echo e(route('add_user_address')); ?>">Add New Address</a></span>
                               </div>
                               <?php endif; ?>
                               <?php echo e($user_address->links()); ?>

                           </div>
                       </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>

    <?php if($brands): ?>
    <div class="brands" id="brands">
    <div class="container-fluid">
        <div class="section-heading mb-2">
            <h2>Our Sponcers</h2>
        </div>
        <ul>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="brand-sec">
                       <?php if($brand['brand_image']!=''): ?>
                      <a href="<?php echo e(url($brand->brand_alias)); ?>"><img src="<?php echo e(url($brand['brand_image'])); ?>" alt=""></a>
                    <?php else: ?>
                       <a href="<?php echo e(url($brand->brand_alias)); ?>"><img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt=""></a>
                    <?php endif; ?>

                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        </ul>

    </div>
</div>
 <?php endif; ?>
<script>
  function UserAddressDelete(id) {
        var _token = '<?php echo csrf_token() ?>';
        $.ajax({
            type: "post",
            url: "<?php echo e(route('user_address_delete')); ?>",
            data: {
                _token: _token,id: id
            },
            before: function() {},
            success: function(data) {
                if (data == 1) {
                    toastr.success('User Address Deleted', 'User Address', {timeOut: 1000,progressBar:true,onHidden:function() {}
                        });
                    //window.location.reload();
                    setTimeout(function() {
                       window.location.reload();
                      }, 1000);
                    }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/121941/resources/views/front/user/user-address.blade.php ENDPATH**/ ?>