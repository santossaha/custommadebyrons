<?php $__env->startSection('content'); ?>
    <style>
        .profile{
            text-align: center;
        }
    </style>
    <h4 class="mb"><b>Edit Contact us</b></h4>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success profile">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <strong><?php echo e(Session::get('success')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="row mt">
        <div class="col-lg-12">
            <div class="form-panel">
                <form class="form-horizontal" action="#" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Name</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e(isset($view->name) ? $view->name : ''); ?>" id="name" name="name" readonly/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Email</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e(isset($view->email) ? $view->email : ''); ?>" id="email" name="email" readonly />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Phone</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e(isset($view->phone) ? $view->phone : ''); ?>" id="phone" name="phone" readonly />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Subject</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e(isset($view->subject) ? $view->subject : ''); ?>" id="subject" name="subject" readonly />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Massage</label>
                        <div class="col-md-6">
                            <textarea name="massage" class="form-control" id="massage" cols="5" readonly rows="5"><?php echo e(isset($view->message) ? $view->message : 'no Massage'); ?></textarea>
                        </div>
                    </div>

                  
                </form>
            </div>
        </div>
        <!-- col-lg-12-->
    </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.fancybox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\121941\resources\views/admin/contact/edit.blade.php ENDPATH**/ ?>