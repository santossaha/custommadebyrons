<?php $__env->startSection('title'); ?>
Privacy Policy
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="banner" class="inner-backg">
    <div class="inner-pg-banner">
        <img src="<?php echo e(url('/')); ?>/front/images/blog-bg.jpg" alt="">
<div class="inner-ban-head">
    <h1><?php echo e(isset($pages['page_name'])?$pages['page_name']:''); ?></h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page"><?php echo e(isset($pages['page_name'])?$pages['page_name']:''); ?></li>
            </ol>
          </nav>
        </div>
    </div>

    </section>


<!--=====privacy & Policy page -content======-->
<section id="privacy-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-md-12">
        <h3><?php echo e(isset($pages['page_title'])?$pages['page_title']:''); ?></h3>

            <ul><?php echo $pages['description']; ?></ul>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\121941\resources\views/front/pages/privacy-policy.blade.php ENDPATH**/ ?>