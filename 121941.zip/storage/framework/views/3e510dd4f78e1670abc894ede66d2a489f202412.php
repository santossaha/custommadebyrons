<?php $__env->startSection('title'); ?>
My Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(url('/')); ?>/front/css/plugins/confirm/jquery-confirm.min.css">
<script src="<?php echo e(url('/')); ?>/front/js/plugins/confirm/jquery-confirm.min.js"></script>
<section id="banner" class="inner-backg">
        <div class="inner-pg-banner">
            <img src="<?php echo e(url('/')); ?>/front/images/blog-bg.jpg" alt="">
            <div class="inner-ban-head">
                <h1>My Profile</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">My Profile</li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <section class="user-dashboard">
        <div class="container-fluid">
            <div class="row">
                <?php echo $__env->make('front.common.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-md-8">
                    <div class="row order-list">
        <div class="col-md-8">
        	<?php echo $__env->make('front.common.Messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div>
                <?php echo e(Form::open(['route' => 'profile_update', 'method' => 'post', 'id' => 'updateprofile',' enctype'=>'multipart/form-data'])); ?>

                    <div class="row">
                      <div class="col-md-6 user-profile">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" value="<?php echo e(isset($users->name)?$users->name:''); ?>" id="name" name="name" placeholder="Name">
                          </div>
                      </div>
                      <div class="col-md-6 user-profile">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo e(isset($users->email)?$users->email:''); ?>" readonly>
                          </div>
                      </div>
                      <div class="col-md-12 user-profile">
                        <label for="formGroupExampleInput custom-lebl">Gender</label>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" id="male" name="gender" class="custom-control-input" value="<?php echo e(isset($users->gender)?$users->gender:'1'); ?>" <?php if($users->gender=='1'): ?> <?php echo e('checked'); ?> <?php endif; ?> >
                            <label class="custom-control-label" for="male">Male</label>
                          </div>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" id="female" name="gender" class="custom-control-input" value="<?php echo e(isset($users->gender)?$users->gender:'2'); ?>" <?php if($users->gender=='2'): ?> <?php echo e('checked'); ?> <?php endif; ?>>
                            <label class="custom-control-label" for="female">Female</label>
                          </div>
                          <span id="error_gender"></span>
                      </div>
                      <div class="col-md-6 user-profile">
                        <div class="form-group">
                            <label for="pincode">Pincode</label>
                            <input type="text" class="form-control" id="pincode" name="pincode" placeholder="Pincode" value="<?php echo e(isset($users->pincode)?$users->pincode:''); ?>">
                          </div>
                      </div>
                      <div class="col-md-6 user-profile">
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control" id="phone" placeholder="Phone Number" value="<?php echo e(isset($users->phone)?$users->phone:''); ?>" name="phone">
                          </div>
                      </div>
                       <div class="col-md-12 user-profile">
                        <div class="form-group">
                            <label class="custom-file-label" for="img">Image upload</label>
                            <input type="file" class="form-control custom-file-input" name="img" placeholder="Choose file" id="img">
                            
                          </div>
                      </div>
                      <div class="col-md-12 user-profile">
                        <div class="form-group">
                            <div class="profile-picture">
                            <?php if($users->image!=''): ?>
                                <img src="<?php echo e(url($users->image)); ?>" class="" id="blah" >
                            <?php else: ?>
                                <img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" class="img-fluid rounded shadow" id="blah" alt="">
                            <?php endif; ?>
                            </div>
                          </div>

                      </div>
                      <div class="col-md-6">
                          <button type="submit" class="btn btn-primary submit-btm">Update</button>
                      </div>
                      
                    </div>
                  <?php echo e(Form::close()); ?>

            </div>
        </div>
      </div>
                </div>
            </div>
        </div>
    </section>

    <?php if($brands): ?>
    <div class="brands" id="brands">
    <div class="container-fluid">


        <div class="section-heading mb-2">
            <h2>Our Sponcers</h2>
        </div>

        <ul>
       
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="brand-sec">
                       <?php if($brand['brand_image']!=''): ?>
                      <a href="<?php echo e(url($brand->brand_alias)); ?>"><img src="<?php echo e(url($brand['brand_image'])); ?>" alt=""></a>
                    <?php else: ?>
                       <a href="<?php echo e(url($brand->brand_alias)); ?>"><img src="<?php echo e(url('/')); ?>/admin/img/No-Image.png" alt=""></a>
                    <?php endif; ?>

                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        </ul>

    </div>
</div>
 <?php endif; ?>
 <script>
     $('#img').change(function() {
        var i = $(this).prev('.file-name').clone();
        var file = $('#img')[0].files[0].name;
        $(this).prev('.custom-file-label').text(file);
    });
    
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $("#updateprofile").validate({
            rules: {
                name: {
                    required: true,
                },
                gender: {
                    required: true
                },
                pincode: {
                    required: true,
                    digits: true
                },
                phone: {
                    required: true,
                    digits: true
                },
            },
            messages: {
                name: {
                    required: "Enter your first name."
                },
                gender: {
                    required: "Select gender."
                },
                pincode: {
                    required: "Enter your pincode.",
                    digits: "Enter valid pincode."
                },
                phone: {
                    required: "Enter phone number.",
                    digits: "Enter valid phone number."
                },
            },
            errorPlacement: function(error, element) {
                if (element.attr("name") == "gender") {
                    error.insertAfter("#error_gender");
                } else {
                    error.insertAfter(element);
                }
            },

        });

    });
     function readURL(input) {
    if (input.files && input.files[0]) {
      var ext = input.files[0].name;
      extension = ext.substring(ext.lastIndexOf('.')+1);
      var reader = new FileReader();
      reader.onload = function(e) {
        if(extension == 'jpg' || extension == 'jpeg' || extension == 'png' || extension == 'JPG' || extension == 'JPEG' || extension == 'PNG'){
          $('#blah').attr('src', e.target.result);
          $('#blah_url').attr('href', e.target.result);
        }else{
          $.alert({
            type:'red',
            title: 'Error!',
            content: 'You can upload JPG, JPEG, PNG files.',
            buttons: {
              ok: function () {

              }
            }
          });
          return false;
          $('#blah').attr('src', '');
                    $('#blah_url').attr('src', '');
        }

      }

      reader.readAsDataURL(input.files[0]);
    }
  }

  $("#img").change(function() {
    readURL(this);
  });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.MainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/121941/resources/views/front/user/my-profile.blade.php ENDPATH**/ ?>