<?php $__env->startSection('content'); ?>

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-9 main-chart">
                    <div class="row mt">
                        <!-- <div class="col-md-4 mb">
                            <div class="white-panel pn">
                                <div class="white-header">
                                    <h5>USERS</h5>
                                </div>
                                <p style="font-size: 21px"><i class="fa fa-user-circle-o" aria-hidden="true"></i></p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="small dashboard-lists">Numbers Of Users</p>
                                        <p>100</p>
                                    </div>
                                    <div class="col-md-6 div-btn" style="padding-top: 16px">
                                        <p class="small dashboard-lists"></p>
                                        <p><a href="#"><button type="button" class="btn-my btn-round btn-info">View</button></a> </p>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                       
                        
                    </div>
                    <!-- /row -->
                  
                </div>

               
            </div>

        </section>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/121941/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>