<?php $__env->startSection('content'); ?>
    <style>
        .profile{
            text-align: center;
        }
    </style>
    <h4 class="mb"><b>Edit Category</b></h4>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success profile">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <strong><?php echo e(Session::get('success')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="row mt">
        <div class="col-lg-12">
            <div class="form-panel">
                <form class="form-horizontal" action="<?php echo e(route('admin::update_category',$info['id'])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label class="col-md-3 control-label">Category Name</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e($info['category_name']); ?>" id="category_name" name="category_name" placeholder="Enter Category Name" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Category Alias</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" value="<?php echo e($info['category_alias']); ?>" id="category_alias" name="category_alias" placeholder="Enter Category Alias" />
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12" style="text-align: center">
                            <button type="submit" class="btn btn-sm btn-success">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- col-lg-12-->
    </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.fancybox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custommadebyrons/public_html/resources/views/admin/category/edit.blade.php ENDPATH**/ ?>